"""
config.py
---------
Central configuration for the multi-step prompt chaining summarization pipeline.
"""

import os

# ----- Paths -----
DOCUMENTS_DIR = os.path.join(os.path.dirname(__file__), "documents")
OUTPUTS_DIR = os.path.join(os.path.dirname(__file__), "outputs")

# ----- Chunking (Step 1) -----
CHUNK_SIZE = 1200        # approx. characters per chunk fed to the "map" summarization step
CHUNK_OVERLAP = 150

# ----- Chain behavior -----
CHUNK_SUMMARY_MAX_SENTENCES = 3   # sentences per per-chunk summary (map step)
FINAL_SUMMARY_MAX_SENTENCES = 6   # sentences in the refined final summary
NUM_KEY_POINTS = 5                # bullet points produced in the final extraction step

# ----- LLM backend -----
# "extractive"  -> no API key needed; each chain step uses classic NLP scoring
#                  (word-frequency sentence ranking) instead of calling a model.
# "anthropic"   -> every chain step is a real Claude call (needs ANTHROPIC_API_KEY)
# "openai"      -> every chain step is a real OpenAI call (needs OPENAI_API_KEY)
LLM_BACKEND = os.environ.get("RAG_CHAIN_LLM_BACKEND", "extractive")

ANTHROPIC_MODEL = "claude-sonnet-4-6"
OPENAI_MODEL = "gpt-4o-mini"
MAX_TOKENS_PER_STEP = 600
