"""
llm_client.py
-------------
A single call_llm(prompt) function used by every step of the prompt chain, so
the rest of the pipeline doesn't care which backend is actually running.

Backends (config.LLM_BACKEND):
  - "extractive" : no API key needed. Used both as the default and as a
                    transparent fallback so the whole pipeline is runnable
                    out of the box.
  - "anthropic"   : real Claude call (ANTHROPIC_API_KEY required)
  - "openai"      : real OpenAI call (OPENAI_API_KEY required)
"""

import os
import re
from collections import Counter

import config


# ---------------------------------------------------------------------------
# Extractive fallback: classic word-frequency sentence scoring (no API calls)
# ---------------------------------------------------------------------------
_STOPWORDS = set("""
a an the this that these those is are was were be been being to of in on for
and or but if then so as at by with from into over under about above below
it its it's he she they them his her their our your you we i not no nor
will would could should can may might shall must has have had do does did
also more most such than which who whom what when where while during within
""".split())


def _split_sentences(text: str):
    text = " ".join(text.split())
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s.strip() for s in sentences if s.strip()]


def _word_freq(text: str) -> Counter:
    words = [w.lower() for w in re.findall(r"[A-Za-z']+", text) if w.lower() not in _STOPWORDS]
    return Counter(words)


def _extractive_summarize(text: str, max_sentences: int) -> str:
    """Rank sentences by summed word-frequency score and keep the top N, in original order."""
    sentences = _split_sentences(text)
    if len(sentences) <= max_sentences:
        return " ".join(sentences)

    freq = _word_freq(text)
    if not freq:
        return " ".join(sentences[:max_sentences])
    max_freq = max(freq.values())
    norm_freq = {w: c / max_freq for w, c in freq.items()}

    scored = []
    for idx, sent in enumerate(sentences):
        words = [w.lower() for w in re.findall(r"[A-Za-z']+", sent)]
        score = sum(norm_freq.get(w, 0) for w in words)
        # mild length penalty so very short sentences don't dominate
        score = score / (len(words) ** 0.3 + 1e-6) if words else 0
        scored.append((score, idx, sent))

    top = sorted(scored, key=lambda x: x[0], reverse=True)[:max_sentences]
    top_in_order = [s for _, _, s in sorted(top, key=lambda x: x[1])]
    return " ".join(top_in_order)


def _extractive_bullets(text: str, n: int):
    freq = _word_freq(text)
    common = [w for w, _ in freq.most_common(n)]
    return common


def extractive_step(instruction: str, text: str, max_sentences: int = None) -> str:
    """
    Local (no-API) implementation used for every chain step when
    config.LLM_BACKEND == "extractive". `instruction` is accepted for a
    consistent call signature but isn't needed for the frequency method.
    """
    max_sentences = max_sentences or config.CHUNK_SUMMARY_MAX_SENTENCES
    return _extractive_summarize(text, max_sentences)


# ---------------------------------------------------------------------------
# Real LLM backends
# ---------------------------------------------------------------------------
def _call_anthropic(prompt: str) -> str:
    import anthropic

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise EnvironmentError("ANTHROPIC_API_KEY environment variable is not set.")

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=config.ANTHROPIC_MODEL,
        max_tokens=config.MAX_TOKENS_PER_STEP,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text").strip()


def _call_openai(prompt: str) -> str:
    from openai import OpenAI

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise EnvironmentError("OPENAI_API_KEY environment variable is not set.")

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=config.OPENAI_MODEL,
        max_tokens=config.MAX_TOKENS_PER_STEP,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content.strip()


def call_llm(prompt: str, backend: str = None) -> str:
    """
    Generic single-shot call used by real-API backends. Each pipeline step
    builds its own prompt and passes it here.
    """
    backend = backend or config.LLM_BACKEND
    if backend == "anthropic":
        return _call_anthropic(prompt)
    elif backend == "openai":
        return _call_openai(prompt)
    else:
        raise ValueError(f"call_llm() does not support backend '{backend}'; "
                          f"use extractive_step() for the extractive backend.")
