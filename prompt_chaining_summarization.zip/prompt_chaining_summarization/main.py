"""
main.py
-------
Command-line entry point for the prompt chaining summarization pipeline.

Usage:
    python main.py summarize documents/sample_article.txt
    python main.py summarize documents/sample_article.txt --quiet
    python main.py summarize documents/sample_article.txt --save

Environment variables (optional, only needed for real LLM backends):
    RAG_CHAIN_LLM_BACKEND = extractive | anthropic | openai   (default: extractive)
    ANTHROPIC_API_KEY       (required if backend=anthropic)
    OPENAI_API_KEY          (required if backend=openai)
"""

import os
import argparse
import json

import config
from chunker import load_document
from pipeline import run_chain


def cmd_summarize(args):
    if not os.path.exists(args.filepath):
        print(f"File not found: {args.filepath}")
        return

    text = load_document(args.filepath)
    print(f"Backend: {config.LLM_BACKEND}")
    print(f"Input file: {args.filepath} ({len(text)} characters)\n")

    trace = run_chain(text, verbose=not args.quiet)

    print("\n" + "=" * 60)
    print(f"TITLE: {trace['title']}")
    print("=" * 60)
    print(f"\nFINAL SUMMARY:\n{trace['final_summary']}")
    print(f"\nKEY POINTS:")
    for p in trace["key_points"]:
        print(f"  - {p}")

    if args.save:
        os.makedirs(config.OUTPUTS_DIR, exist_ok=True)
        base = os.path.splitext(os.path.basename(args.filepath))[0]
        out_path = os.path.join(config.OUTPUTS_DIR, f"{base}_chain_trace.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(trace, f, indent=2)
        print(f"\nFull chain trace (all intermediate steps) saved to: {out_path}")


def build_parser():
    parser = argparse.ArgumentParser(description="Prompt Chaining Summarization Pipeline")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_sum = subparsers.add_parser("summarize", help="Run the full prompt chain on a document")
    p_sum.add_argument("filepath", type=str, help="Path to a .txt file to summarize")
    p_sum.add_argument("--quiet", action="store_true", help="Suppress step-by-step progress logs")
    p_sum.add_argument("--save", action="store_true", help="Save the full chain trace as JSON")
    p_sum.set_defaults(func=cmd_summarize)

    return parser


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
