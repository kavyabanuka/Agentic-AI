"""
pipeline.py
-----------
The prompt CHAIN itself. Each function is one link: it takes the previous
step's output as input and produces the next step's input. Running the whole
chain is Step1 -> Step2 -> Step3 -> Step4, with every intermediate result kept
so you can inspect exactly what each step contributed.

    Step 1 (map)      summarize_chunk()        -> one summary per document chunk
    Step 2 (reduce)   combine_summaries()       -> merges chunk summaries into a draft
    Step 3 (refine)   refine_summary()          -> tightens the draft into a clean final summary
    Step 4 (extract)  extract_title_and_points() -> derives a title + key bullet points
                                                     FROM the final summary (not the raw text)

This mirrors a real prompt-chaining architecture: later prompts are built
from the outputs of earlier prompts rather than from the raw source each time.
"""

from typing import List, Dict

import config
from chunker import chunk_text
from llm_client import call_llm, extractive_step, _extractive_bullets


def _run_step(prompt_instruction: str, source_text: str, max_sentences: int) -> str:
    """
    Dispatches a single chain step to whichever backend is configured.
    `prompt_instruction` is only used for the real-LLM backends; the
    extractive backend ignores it and scores sentences directly.
    """
    if config.LLM_BACKEND == "extractive":
        return extractive_step(prompt_instruction, source_text, max_sentences)

    prompt = f"{prompt_instruction}\n\n---\n{source_text}\n---"
    return call_llm(prompt)


# ---------------------------------------------------------------------------
# Step 1 (map): summarize each chunk independently
# ---------------------------------------------------------------------------
def summarize_chunk(chunk: str, chunk_index: int) -> str:
    instruction = (
        "Summarize the following passage in 2-3 concise sentences. "
        "Preserve concrete facts, numbers, and names. Do not add outside information."
    )
    return _run_step(instruction, chunk, config.CHUNK_SUMMARY_MAX_SENTENCES)


def map_step(chunks: List[str]) -> List[str]:
    return [summarize_chunk(c, i) for i, c in enumerate(chunks)]


# ---------------------------------------------------------------------------
# Step 2 (reduce): merge the per-chunk summaries into one draft summary
# ---------------------------------------------------------------------------
def combine_summaries(chunk_summaries: List[str]) -> str:
    combined_text = " ".join(chunk_summaries)
    instruction = (
        "The following are summaries of consecutive sections of one document. "
        "Combine them into a single coherent draft summary, removing redundancy "
        "and preserving the overall narrative and key facts."
    )
    # feeds Step 1's OUTPUT as Step 2's input -- this is the "chain" part
    return _run_step(instruction, combined_text, config.FINAL_SUMMARY_MAX_SENTENCES + 2)


# ---------------------------------------------------------------------------
# Step 3 (refine): polish the draft into a tight, well-written final summary
# ---------------------------------------------------------------------------
def refine_summary(draft_summary: str) -> str:
    instruction = (
        f"Rewrite the following draft summary so it reads as one polished, "
        f"coherent summary in at most {config.FINAL_SUMMARY_MAX_SENTENCES} sentences. "
        f"Remove repetition and filler, keep it factual, and do not add new claims."
    )
    return _run_step(instruction, draft_summary, config.FINAL_SUMMARY_MAX_SENTENCES)


# ---------------------------------------------------------------------------
# Step 4 (extract): derive a title + key points FROM the refined summary
# ---------------------------------------------------------------------------
def extract_title_and_points(final_summary: str) -> Dict:
    if config.LLM_BACKEND == "extractive":
        sentences = [s.strip() for s in final_summary.split(".") if s.strip()]
        title = sentences[0][:80] if sentences else "Summary"
        # use each remaining sentence of the final summary as a key point,
        # capped at NUM_KEY_POINTS, so points are grounded in real content
        # rather than isolated keyword mentions
        candidate_points = sentences[1:] if len(sentences) > 1 else sentences
        key_points = [s + "." for s in candidate_points[:config.NUM_KEY_POINTS]]
        if not key_points:
            key_points = ["No additional key points found."]
        return {"title": title, "key_points": key_points}

    instruction = (
        f"Based only on the summary below, produce:\n"
        f"1) A short descriptive title (max 10 words)\n"
        f"2) Exactly {config.NUM_KEY_POINTS} key bullet points\n"
        f"Format strictly as:\nTITLE: <title>\nPOINTS:\n- point 1\n- point 2\n..."
    )
    raw = _run_step(instruction, final_summary, config.NUM_KEY_POINTS)
    return _parse_title_and_points(raw)


def _parse_title_and_points(raw: str) -> Dict:
    title = "Summary"
    points = []
    for line in raw.splitlines():
        line = line.strip()
        if line.upper().startswith("TITLE:"):
            title = line.split(":", 1)[1].strip()
        elif line.startswith("-"):
            points.append(line.lstrip("- ").strip())
    if not points:
        points = [raw.strip()]
    return {"title": title, "key_points": points}


# ---------------------------------------------------------------------------
# Full chain runner
# ---------------------------------------------------------------------------
def run_chain(document_text: str, verbose: bool = True) -> Dict:
    """
    Runs the full 4-step prompt chain and returns every intermediate result
    plus the final output, so the chaining behavior is fully inspectable.
    """
    trace = {}

    chunks = chunk_text(document_text)
    trace["step0_chunks"] = chunks
    if verbose:
        print(f"[Step 0] Split document into {len(chunks)} chunk(s).")

    chunk_summaries = map_step(chunks)
    trace["step1_chunk_summaries"] = chunk_summaries
    if verbose:
        print(f"[Step 1 - map] Produced {len(chunk_summaries)} chunk summaries.")

    draft_summary = combine_summaries(chunk_summaries)
    trace["step2_draft_summary"] = draft_summary
    if verbose:
        print("[Step 2 - reduce] Combined chunk summaries into a draft summary.")

    final_summary = refine_summary(draft_summary)
    trace["step3_final_summary"] = final_summary
    if verbose:
        print("[Step 3 - refine] Polished draft into the final summary.")

    extracted = extract_title_and_points(final_summary)
    trace["step4_title"] = extracted["title"]
    trace["step4_key_points"] = extracted["key_points"]
    if verbose:
        print("[Step 4 - extract] Derived title and key points from the final summary.")

    trace["final_summary"] = final_summary
    trace["title"] = extracted["title"]
    trace["key_points"] = extracted["key_points"]
    return trace
