# Prompt Chaining for Summarization

A multi-step **prompt chaining** pipeline: instead of one giant "summarize this" prompt,
the task is broken into a sequence of smaller prompts where each step's output becomes
the next step's input. Runs out of the box with no API key required, and can optionally
be upgraded to run every step as a real Claude or OpenAI call.

## The chain

```
Step 0  chunk_text()               Split the raw document into overlapping chunks
Step 1  summarize_chunk()   (map)   Summarize each chunk independently
Step 2  combine_summaries() (reduce) Merge all chunk summaries into one draft summary
Step 3  refine_summary()   (refine) Polish the draft into a tight, coherent final summary
Step 4  extract_title_and_points()  Derive a title + key bullet points FROM the final summary
```

Step 3 never sees the raw document — only Step 2's output. Step 4 never sees the raw
document either — only Step 3's output. That dependency chain (each prompt built from the
previous prompt's result, not from scratch) is the "prompt chaining" pattern being
demonstrated here.

## Folder contents

```
prompt_chaining_summarization/
├── config.py            # all settings (chunk size, sentence limits, backend, etc.)
├── llm_client.py         # unified call_llm(); extractive fallback + Claude/OpenAI backends
├── chunker.py             # splits raw text into overlapping chunks
├── pipeline.py             # the 4-step chain itself (the core of this project)
├── main.py                  # command-line entry point
├── requirements.txt
├── documents/
│   └── sample_article.txt   # sample doc so the demo runs instantly
└── outputs/                 # JSON chain traces get saved here with --save
```

## 1. Install dependencies

```bash
pip install -r requirements.txt
```

The default backend (`extractive`) uses only the Python standard library — nothing to
install, no internet needed, no API key.

## 2. Run the chain

```bash
python main.py summarize documents/sample_article.txt
```

Flags:
- `--quiet` — suppress the step-by-step "[Step N] ..." progress log
- `--save` — write the full chain trace (every intermediate output) to `outputs/<file>_chain_trace.json`

Try it on your own document:
```bash
python main.py summarize path/to/your_article.txt --save
```

## Switching to a real LLM for every step

By default each step runs a local word-frequency extractive method
(`llm_client.extractive_step`), so the chain works immediately without any setup. To have
every step call an actual model instead:

```bash
pip install anthropic
export ANTHROPIC_API_KEY=your-key-here
export RAG_CHAIN_LLM_BACKEND=anthropic
python main.py summarize documents/sample_article.txt
```

or with OpenAI:

```bash
pip install openai
export OPENAI_API_KEY=your-key-here
export RAG_CHAIN_LLM_BACKEND=openai
python main.py summarize documents/sample_article.txt
```

Every step's prompt text lives in `pipeline.py` (`summarize_chunk`, `combine_summaries`,
`refine_summary`, `extract_title_and_points`) — edit those instruction strings to change
what each link in the chain asks the model to do.

## Configuration

All tunables are in `config.py`:

| Setting | Purpose | Default |
|---|---|---|
| `CHUNK_SIZE` / `CHUNK_OVERLAP` | how the document is split before Step 1 | 1200 / 150 chars |
| `CHUNK_SUMMARY_MAX_SENTENCES` | length of each Step 1 chunk summary | 3 |
| `FINAL_SUMMARY_MAX_SENTENCES` | length of the Step 3 final summary | 6 |
| `NUM_KEY_POINTS` | how many bullets Step 4 produces | 5 |
| `LLM_BACKEND` (env: `RAG_CHAIN_LLM_BACKEND`) | `extractive` \| `anthropic` \| `openai` | `extractive` |

## Why chain instead of one prompt?

- **Long documents**: a single prompt can exceed context limits; chunking + map/reduce
  lets you summarize arbitrarily long input.
- **Better quality**: separating "extract facts" (Step 1-2) from "polish prose" (Step 3)
  from "derive structure" (Step 4) generally produces more reliable output than asking
  one prompt to do everything at once.
- **Inspectability**: `--save` gives you the full trace, so you can see exactly which
  step introduced an error or dropped a detail — much harder to debug a single monolithic
  prompt.
